import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional
import json
import os

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from apscheduler.schedulers.asyncio import AsyncIOScheduler

# Налаштування логування
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Файл для збереження даних
DATA_FILE = "tasks.json"

# FSM стани для додавання завдання
class TaskStates(StatesGroup):
    waiting_for_task = State()
    waiting_for_reminder = State()
    editing_task = State()

# Клас для роботи з даними
class TaskStorage:
    def __init__(self, filename: str):
        self.filename = filename
        self.load_data()
    
    def load_data(self):
        """Завантажує дані з JSON файлу"""
        if os.path.exists(self.filename):
            with open(self.filename, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
        else:
            self.data = {}
    
    def save_data(self):
        """Зберігає дані у JSON файл"""
        with open(self.filename, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def get_user_tasks(self, user_id: int) -> list:
        """Отримує всі завдання користувача"""
        user_id_str = str(user_id)
        if user_id_str not in self.data:
            self.data[user_id_str] = []
        return self.data[user_id_str]
    
    def add_task(self, user_id: int, task_text: str, reminder: Optional[str] = None):
        """Додає нове завдання"""
        user_tasks = self.get_user_tasks(user_id)
        task_id = len(user_tasks) + 1
        
        task = {
            "id": task_id,
            "text": task_text,
            "completed": False,
            "created_at": datetime.now().isoformat(),
            "reminder": reminder
        }
        
        user_tasks.append(task)
        self.save_data()
        return task
    
    def delete_task(self, user_id: int, task_id: int) -> bool:
        """Видаляє завдання"""
        user_tasks = self.get_user_tasks(user_id)
        for i, task in enumerate(user_tasks):
            if task["id"] == task_id:
                user_tasks.pop(i)
                self.save_data()
                return True
        return False
    
    def toggle_task(self, user_id: int, task_id: int) -> bool:
        """Змінює статус завдання (виконано/не виконано)"""
        user_tasks = self.get_user_tasks(user_id)
        for task in user_tasks:
            if task["id"] == task_id:
                task["completed"] = not task["completed"]
                self.save_data()
                return True
        return False
    
    def edit_task(self, user_id: int, task_id: int, new_text: str) -> bool:
        """Редагує текст завдання"""
        user_tasks = self.get_user_tasks(user_id)
        for task in user_tasks:
            if task["id"] == task_id:
                task["text"] = new_text
                self.save_data()
                return True
        return False
    
    def get_task_by_id(self, user_id: int, task_id: int):
        """Отримує конкретне завдання"""
        user_tasks = self.get_user_tasks(user_id)
        for task in user_tasks:
            if task["id"] == task_id:
                return task
        return None

# Ініціалізація
storage = TaskStorage(DATA_FILE)
scheduler = AsyncIOScheduler()

# Функція для відправки нагадувань
async def send_reminder(bot: Bot, user_id: int, task_text: str):
    """Відправляє нагадування користувачу"""
    try:
        await bot.send_message(
            user_id,
            f"⏰ <b>Нагадування!</b>\n\n📌 {task_text}",
            parse_mode="HTML"
        )
    except Exception as e:
        logger.error(f"Помилка при відправці нагадування: {e}")

def create_tasks_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Створює клавіатуру зі списком завдань"""
    tasks = storage.get_user_tasks(user_id)
    keyboard = []
    
    for task in tasks:
        status = "✅" if task["completed"] else "❌"
        text = f"{status} {task['id']}. {task['text'][:30]}..."
        keyboard.append([InlineKeyboardButton(
            text=text,
            callback_data=f"task_{task['id']}"
        )])
    
    keyboard.append([InlineKeyboardButton(text="➕ Додати завдання", callback_data="add_task")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def create_task_actions_keyboard(task_id: int) -> InlineKeyboardMarkup:
    """Створює клавіатуру з діями для завдання"""
    keyboard = [
        [
            InlineKeyboardButton(text="✏️ Редагувати", callback_data=f"edit_{task_id}"),
            InlineKeyboardButton(text="✅/❌ Статус", callback_data=f"toggle_{task_id}")
        ],
        [
            InlineKeyboardButton(text="🗑 Видалити", callback_data=f"delete_{task_id}"),
            InlineKeyboardButton(text="◀️ Назад", callback_data="back_to_list")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

# Обробники команд
async def cmd_start(message: types.Message):
    """Обробник команди /start"""
    await message.answer(
        "👋 Вітаю! Я ToDo бот.\n\n"
        "Я допоможу вам керувати вашими завданнями:\n"
        "• Додавати нові завдання\n"
        "• Редагувати та видаляти їх\n"
        "• Встановлювати нагадування\n"
        "• Відмічати виконані завдання\n\n"
        "Використовуйте /help для перегляду всіх команд.",
        reply_markup=create_tasks_keyboard(message.from_user.id)
    )

async def cmd_help(message: types.Message):
    """Обробник команди /help"""
    help_text = """
📋 <b>Доступні команди:</b>

/start - Почати роботу з ботом
/list - Показати всі завдання
/add - Додати нове завдання
/help - Показати цю довідку

<b>Як використовувати:</b>

1️⃣ Натисніть кнопку або використайте /add для додавання завдання
2️⃣ Введіть текст завдання
3️⃣ Вкажіть час нагадування (необов'язково)
4️⃣ Керуйте завданнями через кнопки

<b>Формат часу нагадування:</b>
• 10м - через 10 хвилин
• 2г - через 2 години
• завтра - завтра о 9:00
    """
    await message.answer(help_text, parse_mode="HTML")

async def cmd_list(message: types.Message):
    """Обробник команди /list"""
    tasks = storage.get_user_tasks(message.from_user.id)
    
    if not tasks:
        await message.answer(
            "📭 У вас поки немає завдань.\n\nНатисніть кнопку нижче, щоб додати перше!",
            reply_markup=create_tasks_keyboard(message.from_user.id)
        )
        return
    
    await message.answer(
        "📋 Ваші завдання:",
        reply_markup=create_tasks_keyboard(message.from_user.id)
    )

async def cmd_add(message: types.Message, state: FSMContext):
    """Обробник команди /add"""
    await state.set_state(TaskStates.waiting_for_task)
    await message.answer(
        "✍️ Напишіть текст завдання:",
        reply_markup=types.ReplyKeyboardMarkup(
            keyboard=[[types.KeyboardButton(text="❌ Скасувати")]],
            resize_keyboard=True
        )
    )

# Обробники callback запитів
async def callback_task_selected(callback: CallbackQuery):
    """Обробник вибору завдання"""
    task_id = int(callback.data.split("_")[1])
    user_id = callback.from_user.id
    task = storage.get_task_by_id(user_id, task_id)
    
    if not task:
        await callback.answer("❌ Завдання не знайдено")
        return
    
    status = "✅ Виконано" if task["completed"] else "❌ Не виконано"
    reminder_text = f"\n⏰ Нагадування: {task['reminder']}" if task.get('reminder') else ""
    
    text = (
        f"📌 <b>Завдання #{task['id']}</b>\n\n"
        f"{task['text']}\n\n"
        f"Статус: {status}"
        f"{reminder_text}\n"
        f"Створено: {task['created_at'][:10]}"
    )
    
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=create_task_actions_keyboard(task_id)
    )
    await callback.answer()

async def callback_add_task(callback: CallbackQuery, state: FSMContext):
    """Обробник кнопки додавання завдання"""
    await state.set_state(TaskStates.waiting_for_task)
    await callback.message.answer(
        "✍️ Напишіть текст завдання:",
        reply_markup=types.ReplyKeyboardMarkup(
            keyboard=[[types.KeyboardButton(text="❌ Скасувати")]],
            resize_keyboard=True
        )
    )
    await callback.answer()

async def callback_delete_task(callback: CallbackQuery):
    """Обробник видалення завдання"""
    task_id = int(callback.data.split("_")[1])
    user_id = callback.from_user.id
    
    if storage.delete_task(user_id, task_id):
        await callback.message.edit_text(
            "✅ Завдання видалено!",
            reply_markup=create_tasks_keyboard(user_id)
        )
    else:
        await callback.answer("❌ Помилка видалення")
    
    await callback.answer()

async def callback_toggle_task(callback: CallbackQuery):
    """Обробник зміни статусу завдання"""
    task_id = int(callback.data.split("_")[1])
    user_id = callback.from_user.id
    
    if storage.toggle_task(user_id, task_id):
        task = storage.get_task_by_id(user_id, task_id)
        status = "✅ Виконано" if task["completed"] else "❌ Не виконано"
        
        text = (
            f"📌 <b>Завдання #{task['id']}</b>\n\n"
            f"{task['text']}\n\n"
            f"Статус: {status}"
        )
        
        await callback.message.edit_text(
            text,
            parse_mode="HTML",
            reply_markup=create_task_actions_keyboard(task_id)
        )
        await callback.answer("✅ Статус змінено!")
    else:
        await callback.answer("❌ Помилка")

async def callback_edit_task(callback: CallbackQuery, state: FSMContext):
    """Обробник кнопки редагування"""
    task_id = int(callback.data.split("_")[1])
    await state.update_data(editing_task_id=task_id)
    await state.set_state(TaskStates.editing_task)
    
    await callback.message.answer(
        "✏️ Введіть новий текст завдання:",
        reply_markup=types.ReplyKeyboardMarkup(
            keyboard=[[types.KeyboardButton(text="❌ Скасувати")]],
            resize_keyboard=True
        )
    )
    await callback.answer()

async def callback_back_to_list(callback: CallbackQuery):
    """Обробник повернення до списку"""
    await callback.message.edit_text(
        "📋 Ваші завдання:",
        reply_markup=create_tasks_keyboard(callback.from_user.id)
    )
    await callback.answer()

# Обробники станів FSM
async def process_new_task(message: types.Message, state: FSMContext):
    """Обробка нового завдання"""
    if message.text == "❌ Скасувати":
        await state.clear()
        await message.answer(
            "❌ Скасовано",
            reply_markup=types.ReplyKeyboardRemove()
        )
        return
    
    task_text = message.text
    await state.update_data(task_text=task_text)
    await state.set_state(TaskStates.waiting_for_reminder)
    
    await message.answer(
        "⏰ Хочете встановити нагадування?\n\n"
        "Введіть час у форматі:\n"
        "• 10м - через 10 хвилин\n"
        "• 2г - через 2 години\n"
        "• завтра - завтра о 9:00\n\n"
        "Або натисніть 'Без нагадування'",
        reply_markup=types.ReplyKeyboardMarkup(
            keyboard=[
                [types.KeyboardButton(text="Без нагадування")],
                [types.KeyboardButton(text="❌ Скасувати")]
            ],
            resize_keyboard=True
        )
    )

async def process_reminder(message: types.Message, state: FSMContext, bot: Bot):
    """Обробка встановлення нагадування"""
    if message.text == "❌ Скасувати":
        await state.clear()
        await message.answer(
            "❌ Скасовано",
            reply_markup=types.ReplyKeyboardRemove()
        )
        return
    
    data = await state.get_data()
    task_text = data['task_text']
    reminder_time = None
    
    if message.text != "Без нагадування":
        reminder_text = message.text.lower()
        
        try:
            if 'м' in reminder_text:
                minutes = int(reminder_text.replace('м', '').strip())
                reminder_time = datetime.now() + timedelta(minutes=minutes)
            elif 'г' in reminder_text:
                hours = int(reminder_text.replace('г', '').strip())
                reminder_time = datetime.now() + timedelta(hours=hours)
            elif 'завтра' in reminder_text:
                tomorrow = datetime.now() + timedelta(days=1)
                reminder_time = tomorrow.replace(hour=9, minute=0, second=0)
            
            if reminder_time:
                scheduler.add_job(
                    send_reminder,
                    'date',
                    run_date=reminder_time,
                    args=[bot, message.from_user.id, task_text]
                )
        except:
            await message.answer("⚠️ Неправильний формат часу. Завдання додано без нагадування.")
    
    task = storage.add_task(
        message.from_user.id,
        task_text,
        reminder_time.strftime("%Y-%m-%d %H:%M") if reminder_time else None
    )
    
    await state.clear()
    await message.answer(
        f"✅ Завдання додано!\n\n"
        f"📌 {task_text}"
        + (f"\n⏰ Нагадування: {reminder_time.strftime('%d.%m.%Y %H:%M')}" if reminder_time else ""),
        reply_markup=types.ReplyKeyboardRemove()
    )

async def process_edit_task(message: types.Message, state: FSMContext):
    """Обробка редагування завдання"""
    if message.text == "❌ Скасувати":
        await state.clear()
        await message.answer(
            "❌ Скасовано",
            reply_markup=types.ReplyKeyboardRemove()
        )
        return
    
    data = await state.get_data()
    task_id = data['editing_task_id']
    new_text = message.text
    
    if storage.edit_task(message.from_user.id, task_id, new_text):
        await message.answer(
            "✅ Завдання оновлено!",
            reply_markup=types.ReplyKeyboardRemove()
        )
    else:
        await message.answer(
            "❌ Помилка оновлення",
            reply_markup=types.ReplyKeyboardRemove()
        )
    
    await state.clear()

async def main():
    """Головна функція запуску бота"""
    # Отримання токена
    TOKEN = os.getenv("BOT_TOKEN")
    if not TOKEN:
        print("❌ Помилка: не вказано BOT_TOKEN")
        print("Встановіть змінну середовища: export BOT_TOKEN='your_token_here'")
        return
    
    # Ініціалізація бота
    bot = Bot(token=TOKEN)
    dp = Dispatcher(storage=MemoryStorage())
    
    # Реєстрація обробників команд
    dp.message.register(cmd_start, Command("start"))
    dp.message.register(cmd_help, Command("help"))
    dp.message.register(cmd_list, Command("list"))
    dp.message.register(cmd_add, Command("add"))
    
    # Реєстрація обробників callback
    dp.callback_query.register(callback_task_selected, F.data.startswith("task_"))
    dp.callback_query.register(callback_add_task, F.data == "add_task")
    dp.callback_query.register(callback_delete_task, F.data.startswith("delete_"))
    dp.callback_query.register(callback_toggle_task, F.data.startswith("toggle_"))
    dp.callback_query.register(callback_edit_task, F.data.startswith("edit_"))
    dp.callback_query.register(callback_back_to_list, F.data == "back_to_list")
    
    # Реєстрація обробників станів
    dp.message.register(process_new_task, TaskStates.waiting_for_task)
    dp.message.register(lambda m, s: process_reminder(m, s, bot), TaskStates.waiting_for_reminder)
    dp.message.register(process_edit_task, TaskStates.editing_task)
    
    # Запуск планувальника
    scheduler.start()
    
    # Запуск бота
    logger.info("🚀 Бот запущено!")
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
