# 🏗 Архітектура проекту

## Загальна схема

```
┌─────────────────┐
│   Telegram API  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   aiogram Bot   │
│   (bot.py)      │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌──────┐  ┌──────────┐
│ FSM  │  │ Handlers │
└──┬───┘  └────┬─────┘
   │           │
   │    ┌──────┴──────┐
   │    │             │
   ▼    ▼             ▼
┌──────────┐    ┌──────────┐
│TaskStorage│    │Scheduler │
└────┬─────┘    └────┬─────┘
     │               │
     ▼               ▼
┌──────────┐    ┌──────────┐
│tasks.json│    │Reminders │
└──────────┘    └──────────┘
```

## Компоненти системи

### 1. Bot (Головний модуль)
**Файл:** `bot.py`

**Відповідальність:**
- Ініціалізація бота
- Реєстрація обробників
- Запуск polling
- Координація між компонентами

**Залежності:**
- aiogram.Bot
- aiogram.Dispatcher
- MemoryStorage для FSM

### 2. TaskStorage (Менеджер даних)
**Клас:** `TaskStorage`

**Методи:**
```python
load_data()              # Завантаження з JSON
save_data()              # Збереження в JSON
get_user_tasks(user_id)  # Отримання завдань користувача
add_task(...)            # Створення завдання
delete_task(...)         # Видалення завдання
toggle_task(...)         # Зміна статусу
edit_task(...)           # Редагування тексту
get_task_by_id(...)      # Пошук завдання
```

**Структура даних:**
```json
{
  "user_id": [
    {
      "id": int,
      "text": string,
      "completed": boolean,
      "created_at": ISO datetime,
      "reminder": string | null
    }
  ]
}
```

### 3. FSM (Finite State Machine)
**Клас:** `TaskStates`

**Стани:**
- `waiting_for_task` - Очікування введення тексту
- `waiting_for_reminder` - Очікування налаштування нагадування
- `editing_task` - Режим редагування

**Потік станів:**
```
[Start] → waiting_for_task → waiting_for_reminder → [Complete]
                                     ↓
                              [No reminder]
                                     ↓
                                [Complete]

[Edit] → editing_task → [Complete]
```

### 4. Scheduler (Планувальник)
**Бібліотека:** APScheduler

**Функції:**
- Планування нагадувань
- Відправка повідомлень у призначений час
- Видалення завершених завдань

**Робочий цикл:**
```
Task created → Parse time → Schedule job → Wait → Send reminder
```

### 5. Handlers (Обробники)

#### Command Handlers
- `/start` → `cmd_start()`
- `/help` → `cmd_help()`
- `/list` → `cmd_list()`
- `/add` → `cmd_add()`

#### Callback Handlers
- `task_{id}` → `callback_task_selected()`
- `add_task` → `callback_add_task()`
- `delete_{id}` → `callback_delete_task()`
- `toggle_{id}` → `callback_toggle_task()`
- `edit_{id}` → `callback_edit_task()`
- `back_to_list` → `callback_back_to_list()`

#### State Handlers
- `TaskStates.waiting_for_task` → `process_new_task()`
- `TaskStates.waiting_for_reminder` → `process_reminder()`
- `TaskStates.editing_task` → `process_edit_task()`

## Діаграма потоку даних

### Додавання завдання
```
User → /add
  ↓
Bot → "Введіть текст"
  ↓
User → "Текст завдання"
  ↓
FSM → waiting_for_task
  ↓
Bot → "Встановити нагадування?"
  ↓
User → "2г" / "Без нагадування"
  ↓
FSM → waiting_for_reminder
  ↓
TaskStorage → add_task()
  ↓
JSON → save_data()
  ↓
(if reminder) Scheduler → schedule job
  ↓
Bot → "✅ Завдання додано"
```

### Редагування завдання
```
User → Click task
  ↓
Bot → Show task details
  ↓
User → Click "✏️ Редагувати"
  ↓
FSM → editing_task
  ↓
Bot → "Введіть новий текст"
  ↓
User → "Новий текст"
  ↓
TaskStorage → edit_task()
  ↓
JSON → save_data()
  ↓
Bot → "✅ Завдання оновлено"
```

## Обробка помилок

### Рівні обробки
1. **Try-Catch блоки** - для критичних операцій
2. **Логування** - для відстеження помилок
3. **Graceful degradation** - робота при часткових збоях

### Типові помилки
```python
# 1. Помилка читання JSON
try:
    with open(file) as f:
        data = json.load(f)
except FileNotFoundError:
    data = {}  # Створити новий файл

# 2. Помилка парсингу часу
try:
    reminder_time = parse_time(text)
except ValueError:
    reminder_time = None  # Без нагадування

# 3. Помилка відправки повідомлення
try:
    await bot.send_message(...)
except Exception as e:
    logger.error(f"Send error: {e}")
```

## Масштабування

### Поточні обмеження
- JSON файл (проблеми при >10000 записів)
- In-memory FSM (втрата при перезапуску)
- Одна інстанція бота

### Можливі покращення

**Крок 1: SQLite**
```python
# Замість JSON
import sqlite3

CREATE TABLE tasks (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    text TEXT,
    completed BOOLEAN,
    created_at TIMESTAMP,
    reminder TIMESTAMP
)
```

**Крок 2: Redis для FSM**
```python
from aiogram.fsm.storage.redis import RedisStorage

storage = RedisStorage.from_url('redis://localhost:6379')
dp = Dispatcher(storage=storage)
```

**Крок 3: Webhook замість polling**
```python
# Для production
from aiogram.webhook.aiohttp_server import SimpleRequestHandler

app = web.Application()
SimpleRequestHandler(dispatcher=dp, bot=bot).register(app, path=WEBHOOK_PATH)
web.run_app(app, host='0.0.0.0', port=8080)
```

## Безпека

### Implemented
- ✅ Токен через змінні середовища
- ✅ Ізоляція даних користувачів
- ✅ Валідація введених даних

### To-Do
- [ ] Rate limiting
- [ ] Шифрування tasks.json
- [ ] Аутентифікація користувачів
- [ ] Логування security events

## Продуктивність

### Метрики
- Час відповіді: < 200ms
- Обробка 100 req/sec (одна інстанція)
- Пам'ять: ~50MB базово

### Оптимізації
```python
# 1. Кешування клавіатур
@lru_cache(maxsize=100)
def create_keyboard(user_id):
    ...

# 2. Batch запити
async def process_multiple_tasks():
    await asyncio.gather(*tasks)

# 3. Ледачне завантаження
def get_tasks(user_id):
    if user_id not in cache:
        cache[user_id] = load_from_db(user_id)
    return cache[user_id]
```

## Тестування

### Unit Tests (TODO)
```python
import pytest

def test_add_task():
    storage = TaskStorage(':memory:')
    task = storage.add_task(123, "Test task")
    assert task['text'] == "Test task"
    assert task['completed'] == False

def test_toggle_task():
    storage = TaskStorage(':memory:')
    task = storage.add_task(123, "Test")
    storage.toggle_task(123, task['id'])
    updated = storage.get_task_by_id(123, task['id'])
    assert updated['completed'] == True
```

### Integration Tests (TODO)
```python
async def test_full_flow():
    # Симуляція користувача
    user_message = Mock(text="/add", from_user=Mock(id=123))
    await cmd_add(user_message, state)
    
    # Перевірка стану
    assert await state.get_state() == TaskStates.waiting_for_task
```

## Deployment

### Локальний запуск
```bash
python bot.py
```

### Docker
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "bot.py"]
```

### Systemd service
```ini
[Unit]
Description=Telegram Todo Bot
After=network.target

[Service]
Type=simple
User=botuser
WorkingDirectory=/opt/todobot
Environment=BOT_TOKEN=xxxxx
ExecStart=/usr/bin/python3 bot.py
Restart=always

[Install]
WantedBy=multi-user.target
```

## Моніторинг (TODO)

```python
# Prometheus metrics
from prometheus_client import Counter, Histogram

tasks_created = Counter('tasks_created', 'Total tasks created')
response_time = Histogram('response_time', 'Response time')

@response_time.time()
async def handle_message(message):
    tasks_created.inc()
    ...
```
